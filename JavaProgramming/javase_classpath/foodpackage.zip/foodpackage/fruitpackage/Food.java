package foodpackage.fruitpackage;

public class Food {

	private String color;
	private String odor;

	public String getColor(){
		return color;
	}

	public void setColor(String color){
		this.color = color;
	}

	public String getOdor(){
		return odor;
	}

	public void setOdor(String odor){
		this.odor = odor;
	}

}